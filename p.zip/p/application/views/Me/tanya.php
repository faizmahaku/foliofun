    <!-- CONTACT -->
     <section id="contact" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-1 col-md-10 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="section-title">
                                   <h1>Punya pertanyaan?</h1>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <input type="text" class="form-control" placeholder="Nama" name="name" required>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <input type="text" class="form-control" placeholder="Telpon" name="email" required>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <input type="submit" class="form-control" name="Kirim" value="Kirim">
                              </div>
                              <div class="col-md-12 col-sm-12">
                                   <textarea class="form-control" rows="8" placeholder="Apa pertanyaan anda..." name="message" required></textarea>
                              </div>
                         </form>
                    </div>

               </div>
          </div>
     </section>