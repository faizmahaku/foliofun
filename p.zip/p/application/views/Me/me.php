
     <!-- FEATURE -->
     <section id="feature" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>Me</h1>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-6">
                         <ul class="nav nav-tabs" role="tablist">
                              <li class="active"><a href="#tab01" aria-controls="tab01" role="tab" data-toggle="tab">Rumah</a></li>

                              <li><a href="#tab02" aria-controls="tab02" role="tab" data-toggle="tab">Kontak</a></li>

                              <li><a href="#tab03" aria-controls="tab03" role="tab" data-toggle="tab">Hobi</a></li>
                         </ul>

                         <div class="tab-content">
                              <div class="tab-pane active" id="tab01" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <h2>Wedung</h2>
                                        <p></p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Demak</h2>
                                        <p></p>
                                   </div>
                              </div>


                              <div class="tab-pane" id="tab02" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <h2>Telepon/WA/Telegram</h2>
                                        <p>+62 89 6466 18000</p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Email</h2>
                                        <p>ahmadfaizulmahasin95@gmail.com</p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Medsos</h2>
                                        <ul class="social-icon">
                                             <li><a target="_blank" href="https://www.facebook.com/faizmakacin/" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                             <!-- <li><a href="#" class="fa fa-twitter"></a></li> -->
                                             <!-- <li><a href="#" class="fa fa-instagram"></a></li> -->
                                             <li><a target="_blank" href="https://www.youtube.com/channel/UCUFJkpHNRwfzcoPIgSPScJA/" class="fa fa-youtube"></a></li>
                                        </ul>
                                   </div>
                              </div>

                              <div class="tab-pane" id="tab03" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <h2>Ngoding</h2>
                                        <p>PHP</p>
                                        <p>CodeIgniter</p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Musik</h2>
                                        <p>Gitar</p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Olah Raga</h2>
                                        <p>Gowes</p>
                                        <p>Renang</p>
                                        <p>Badminton</p>
                                        <p>Sepak Bola Kampung</p>
                                   </div><div class="tab-pane-item">
                                        <h2>Otak-atik</h2>
                                        <p></p>
                                   </div>
                              </div>
                         </div>

                    </div>

                    <div class="col-md-6 col-sm-6">
                         <div class="feature-image">
                              <img  src="<?= base_url('assets/u/'); ?>images/me.jpg" class="img-responsive img-circle" alt="Thin Laptop">                             
                         </div>
                    </div>

               </div>
          </div>
     </section>