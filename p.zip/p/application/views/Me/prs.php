     <!-- PRICING -->
     <section id="pricing" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>Produk</h1>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="pricing-thumb">
                             <div class="pricing-title">
                                  <h2>Student</h2>
                             </div>
                             <div class="pricing-info">
                                   <p>20 Responsive Designs</p>
                                   <p>10 Dashboards</p>
                                   <p>1 TB Storage</p>
                                   <p>6 TB Bandwidth</p>
                                   <p>24-hour Support</p>
                             </div>
                             <div class="pricing-bottom">
                                   <span class="pricing-dollar">$200/mo</span>
                                   <a href="#" class="section-btn pricing-btn">Register now</a>
                             </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="pricing-thumb">
                             <div class="pricing-title">
                                  <h2>Business</h2>
                             </div>
                             <div class="pricing-info">
                                   <p>50 Responsive Designs</p>
                                   <p>30 Dashboards</p>
                                   <p>2 TB Storage</p>
                                   <p>12 TB Bandwidth</p>
                                   <p>15-minute Support</p>
                             </div>
                             <div class="pricing-bottom">
                                   <span class="pricing-dollar">$350/mo</span>
                                   <a href="#" class="section-btn pricing-btn">Register now</a>
                             </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="pricing-thumb">
                             <div class="pricing-title">
                                  <h2>Professional</h2>
                             </div>
                             <div class="pricing-info">
                                   <p>100 Responsive Designs</p>
                                   <p>60 Dashboards</p>
                                   <p>5 TB Storage</p>
                                   <p>25 TB Bandwidth</p>
                                   <p>1-minute Support</p>
                             </div>
                             <div class="pricing-bottom">
                                   <span class="pricing-dollar">$550/mo</span>
                                   <a href="#" class="section-btn pricing-btn">Register now</a>
                             </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>   