<!-- FOOTER -->
<footer id="footer" data-stellar-background-ratio="0.5">
     <div class="container">
          <div class="row">

               <div class="copyright-text col-md-12 col-sm-12">
                    <div class="col-md-6 col-sm-6">
                         <p>Dibuat <?= date("l, d M Y", strtotime("6 jul 2020")); ?> Copyright &copy; <?= date('Y') ?> AFM.COM - Design: Tooplate</p>
                    </div>

                    <div class="col-md-6 col-sm-6">
                         <ul class="social-icon">
                              <li><a target="_blank" href="https://www.facebook.com/faizmakacin/" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                              <!-- <li><a href="#" class="fa fa-twitter"></a></li> -->
                              <!-- <li><a href="#" class="fa fa-instagram"></a></li> -->
                              <li><a target="_blank" href="https://www.youtube.com/channel/UCUFJkpHNRwfzcoPIgSPScJA/" class="fa fa-youtube"></a></li>
                         </ul>
                    </div>
               </div>

          </div>
     </div>
</footer>
<!-- SCRIPTS -->
<script src="<?= base_url('assets/u/'); ?>js/jquery.js"></script>
<script src="<?= base_url('assets/u/'); ?>js/bootstrap.min.js"></script>
<script src="<?= base_url('assets/u/'); ?>js/jquery.stellar.min.js"></script>
<script src="<?= base_url('assets/u/'); ?>js/owl.carousel.min.js"></script>
<script src="<?= base_url('assets/u/'); ?>js/smoothscroll.js"></script>
<script src="<?= base_url('assets/u/'); ?>js/custom.js"></script>

</body>

</html>