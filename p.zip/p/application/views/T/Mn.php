    <!-- MENU -->
    <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
         <div class="container">
              <div class="navbar-header">
                   <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon icon-bar"></span>
                        <span class="icon icon-bar"></span>
                        <span class="icon icon-bar"></span>
                   </button>
                   <!-- lOGO TEXT HERE -->
                   <a href="<?= base_url('mi'); ?>" class="navbar-brand">AFM<sup><?= date('Y') ?></sup></a>
              </div>

              <!-- MENU LINKS -->
              <div class="collapse navbar-collapse">
                   <ul class="nav navbar-nav">
                   </ul>
                   <ul class="nav navbar-nav navbar-right">
                        <li><a href="#home" class="smoothScroll">Beranda</a></li>
                        <li><a href="#feature" class="smoothScroll">Me</a></li>
                        <li><a href="#about" class="smoothScroll">Rekan</a></li>
                        <li><a href="#pricing" class="smoothScroll">Produk</a></li>
                        <li><a href="#contact" class="smoothScroll">Tanya</a></li>
                        <li>
                             <!-- fungsi menampilkan tgl -->
                             <a href="#" class="smoothScroll">
                                  <?php $hari = date("d F");
                                   $day = date('D', strtotime($hari));
                                   $daylist = array(
                                        'Sun' => 'Ahad',
                                        'Mon' => 'Senin',
                                        'Tue' => 'Selasa',
                                        'Wed' => 'Rabu',
                                        'Thu' => 'Kamis',
                                        'Fri' => "Jum'at",
                                        'Sat' => 'Senin'
                                   );
                                   echo $daylist[$day] . "," . " " . $hari;
                                   // echo "<b>". $daylist[$day] .","." ". $tanggal . "</b>";
                                   ?>
                             </a>
                        </li>
                        <li>
                             <!-- fungsi menamplkan jam -->
                             <a href="#">
                                  <script type="text/javascript">
                                       function tampilkanwaktu() {
                                            var waktu = new Date();
                                            var sh = waktu.getHours() + "";
                                            var sm = waktu.getMinutes() + "";
                                            var ss = waktu.getSeconds() + "";
                                            document.getElementById("clock")
                                                 .innerHTML = (sh.length == 1 ? +sh : sh) + " : " + (sm.length == 1 ? "0" + sm : sm) + " : " + (ss.length == 1 ? "0" + ss : ss);
                                       }
                                  </script>
                                  <span id="clock">

                                       <body onload="tampilkanwaktu(); setInterval('tampilkanwaktu()', 1000)">
                                  </span>
                             </a>
                        </li>
                        <li><a href="<?= base_url('mi/er'); ?>"><span>Login</span></a></li>
                   </ul>
              </div>
         </div>
    </section>