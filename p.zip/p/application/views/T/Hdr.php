<!DOCTYPE html>
<html lang="en">

<head>

    <title><?= $title; ?></title>
    <!--

    Template 2106 Soft Landing

	http://www.tooplate.com/view/2106-soft-landing

    -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="team" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="<?= base_url('assets/u/'); ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/u/'); ?>css/owl.carousel.css">
    <link rel="stylesheet" href="<?= base_url('assets/u/'); ?>css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/u/'); ?>css/font-awesome.min.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/u/'); ?>css/tooplate-style.css">

</head>

<body>