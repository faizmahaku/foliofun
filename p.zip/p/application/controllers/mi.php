<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mi extends CI_Controller {

	public function index()
	{
		$data['title'] = "AFM.COM";

		$this->load->view('T/hdr', $data);
		$this->load->view('T/mn');
		$this->load->view('Me/index');
		$this->load->view('Me/me');
		$this->load->view('Me/rekan');
		$this->load->view('Me/prs');
		$this->load->view('Me/tanya');
		$this->load->view('T/ftr');
	}

}